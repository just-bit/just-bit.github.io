lg-thumbnail   - библиотека миниатюр
lg-fullscreen  - библиотека для полного єкрана
lg-zoom        - zoom
lg-rotate      - rotate
lg-share       - поделиться
lg-hash        - hash
lg-autoplay    - autoplay
lg-video       - video

fonts - для значков галлереи
