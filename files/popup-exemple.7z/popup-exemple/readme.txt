popup
======

фомат ссылки на попап
<a class="_popup-link" href="#myclass">link to popup</a>

в самом попапе #myclass прописываем как popup_myclass
<div class="popup popup_myclass">