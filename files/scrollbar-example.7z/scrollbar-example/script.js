// один элемент
// var myElement = document.querySelector('.block-single');
// new SimpleBar(myElement);


// коллекция
document.querySelectorAll('.block').forEach(el => {
	new SimpleBar(el)
});




// .block.simplebar - horizontal {
// 	height: 8px;
// 	margin: 10px;
// 	margin - right: 30px;
// }

// .block.simplebar - horizontal.simplebar - scrollbar:: before {
// 	left: 5px;
// 	right: 5px;
// }