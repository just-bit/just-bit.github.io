tabs
=====
_tabs
_tabs-item
_tabs-block
_active (добавить, если показать изначально)

.my-tabs-wrapper._tabs
	.my-tabs-block__nav
		my-span._tabs-item._active
		my-span._tabs-item
		my-span._tabs-item	
	.my-tabs-block__body
		my-span._tabs-block._active
		my-span._tabs-block
		my-span._tabs-block