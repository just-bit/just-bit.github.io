const mySelect = () => {
	const element = document.querySelector('.selo');
	const choices = new Choices(element, {
		searchEnabled: false
	});
};

mySelect();
